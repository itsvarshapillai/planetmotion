# Planetary Motion

![Alt](https://github.com/aswinanil2829/PatternGenerator/blob/master/made-with-c%2B%2B.svg)       

![GitHub last commit](https://img.shields.io/github/last-commit/aswinanil2829/PatternGenerator)

A small project to showcase an animated planetary motion through  visual studio

## Usage

1. Clone this repository using :
 
   Using HTTPS:
      ``` 
     git clone https://github.com/aswinanil2829/PatternGenerator.git
      ```
  
    Using SSH :
      ```
      git clone git@github.com:aswinanil2829/PatternGenerator.git
      ```      
2.open the cloned folder in Visual Studio

3.Debug and Run

## How it looks like

![image](https://github.com/aswinanil2829/PatternGenerator/blob/master/pic.jpg)

## YouTube Video
       https://youtu.be/PCrEL4ZGIF0

